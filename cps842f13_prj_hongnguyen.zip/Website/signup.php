<!doctype html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<meta charset="utf-8">
<title>Movie Rater | Signup</title>
</head>
 
<table>
<form name="register_form" method="post" action="processsignup.php">
<th colspan="2">Register New Account</th>
<tr>
	<td>Username:</td>
	<td><input name="username" type="text" id="username" size="30" required autofocus></td>
</tr>
<tr>
	<td>Password:</td>
	<td><input name="password" type="text" id="password" size="30" required></td>
</tr>
<tr>
	<td colspan="3"><input type="submit" name="Submit" value="Register">
	</td>
</tr>
</form>
</table>
<small>Already a member? <a href="index.html">Click here to login</a></small>

</body>
</html>